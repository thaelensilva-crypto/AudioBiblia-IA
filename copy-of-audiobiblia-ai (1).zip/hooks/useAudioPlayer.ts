
import { useState, useEffect, useRef, useCallback } from 'react';
import { decode, decodeAudioData } from '../utils/audio';

// Gemini TTS returns 24000Hz mono audio
const SAMPLE_RATE = 24000;
const NUM_CHANNELS = 1;

export const useAudioPlayer = (audioB64: string | null) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isReady, setIsReady] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const progressIntervalRef = useRef<number | null>(null);
  const startedAtRef = useRef(0);
  
  const cleanup = useCallback(() => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.stop();
      } catch(e) {
        // Can throw if already stopped or not started
      }
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }
  }, []);
  
  const pause = useCallback(() => {
    cleanup();
    setIsPlaying(false);
  }, [cleanup]);

  const play = useCallback(() => {
    if (!isReady || !audioBufferRef.current || !audioContextRef.current) return;

    if (audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
    }
    
    cleanup();
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBufferRef.current;
    source.connect(audioContextRef.current.destination);
    
    const offset = progress * duration;
    source.start(0, offset);
    
    sourceNodeRef.current = source;
    startedAtRef.current = audioContextRef.current.currentTime - offset;

    setIsPlaying(true);

    progressIntervalRef.current = window.setInterval(() => {
      if (audioContextRef.current && audioBufferRef.current) {
        const elapsed = audioContextRef.current.currentTime - startedAtRef.current;
        const newProgress = Math.min(elapsed / duration, 1);
        setProgress(newProgress);
        if (newProgress >= 1) {
          setProgress(1);
          pause();
        }
      }
    }, 100);

     source.onended = () => {
        if (sourceNodeRef.current === source) {
            pause();
            if (progress >= 0.99) {
                setProgress(0); // Reset for next play if it finished naturally
            }
        }
    };
  }, [isReady, duration, progress, cleanup, pause]);


  useEffect(() => {
    if (audioB64) {
      setIsReady(false);
      cleanup();
      const initAudio = async () => {
        try {
          if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: SAMPLE_RATE });
          }
          const audioBytes = decode(audioB64);
          const buffer = await decodeAudioData(audioBytes, audioContextRef.current, SAMPLE_RATE, NUM_CHANNELS);
          audioBufferRef.current = buffer;
          setDuration(buffer.duration);
          setProgress(0);
          setIsPlaying(false);
          setIsReady(true);
        } catch (error) {
          console.error("Failed to decode audio data", error);
          setIsReady(false);
        }
      };
      initAudio();
    }
    return cleanup;
  }, [audioB64, cleanup]);


  const seek = (newProgress: number) => {
    if (!duration || !isReady) return;
    const wasPlaying = isPlaying;
    pause();
    setProgress(newProgress);
    if (wasPlaying) {
      // Use timeout to allow state to update before playing
      setTimeout(() => play(), 0);
    }
  };

  const skip = (amount: number) => {
    if(!duration || !isReady) return;
    const newTime = (progress * duration) + amount;
    const newProgress = Math.max(0, Math.min(newTime / duration, 1));
    seek(newProgress);
  }

  const togglePlayPause = () => {
    if (isPlaying) {
      pause();
    } else {
      if (progress >= 0.99) { // If at the end, restart
          seek(0);
          setTimeout(() => play(), 0); // use timeout to play with fresh progress state
      } else {
          play();
      }
    }
  };

  return { isPlaying, progress, duration, isReady, togglePlayPause, seek, skip };
};
