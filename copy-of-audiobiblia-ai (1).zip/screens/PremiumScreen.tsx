import React, { useState } from 'react';
import type { SubscriptionPlan } from '../types';
import { CheckCircle, ChevronLeft, Gem, Percent } from 'lucide-react';

interface PremiumScreenProps {
  onBack: () => void;
}

const PremiumScreen: React.FC<PremiumScreenProps> = ({ onBack }) => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>('annual');
  const [discountCode, setDiscountCode] = useState('');
  const [isDiscountApplied, setIsDiscountApplied] = useState(false);

  const handleApplyDiscount = () => {
    if (discountCode.toLowerCase() === '10off') {
      setIsDiscountApplied(true);
    } else {
      alert('Código de desconto inválido.');
    }
  };
  
  const getPrice = (plan: SubscriptionPlan) => {
    let price = plan === 'monthly' ? 19.90 : 97.00;
    if (isDiscountApplied) {
      price *= 0.90;
    }
    return price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  return (
    <div className="flex flex-col h-full bg-slate-50">
      <header className="p-4 flex items-center border-b border-slate-200/80">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-black/5"><ChevronLeft className="w-6 h-6 text-slate-600"/></button>
        <h2 className="text-xl font-bold text-slate-800 ml-4">AudioBiblia AI Premium</h2>
      </header>

      <main className="flex-grow p-6 text-center overflow-y-auto">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-sky-500 rounded-2xl text-white inline-block">
          <Gem className="w-10 h-10" />
        </div>
        <h3 className="text-2xl font-bold mt-4 text-slate-800">Desbloqueie Todo o Potencial</h3>
        <p className="text-slate-500 mt-2">Acesso ilimitado e recursos exclusivos.</p>

        <ul className="text-left space-y-3 my-8">
          {['Escaneamentos ilimitados', 'Qualidade de áudio HD', 'Processamento mais rápido', 'Sem anúncios'].map(feature => (
            <li key={feature} className="flex items-center">
              <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
              <span className="text-slate-700">{feature}</span>
            </li>
          ))}
        </ul>
        
        <div className="space-y-4">
          <PlanCard 
            plan="monthly"
            price="R$19,90"
            period="/mês"
            isSelected={selectedPlan === 'monthly'}
            onClick={() => setSelectedPlan('monthly')}
          />
          <PlanCard 
            plan="annual"
            price="R$97,00"
            period="/ano"
            badge="Economize 59%"
            isSelected={selectedPlan === 'annual'}
            onClick={() => setSelectedPlan('annual')}
          />
        </div>

        <div className="mt-6">
          <div className="relative">
            <input 
              type="text"
              placeholder="Código de desconto"
              value={discountCode}
              onChange={(e) => setDiscountCode(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-full focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <Percent className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"/>
            <button 
              onClick={handleApplyDiscount}
              className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-1.5 bg-slate-200 text-slate-700 text-sm font-semibold rounded-full hover:bg-slate-300"
            >
              Aplicar
            </button>
          </div>
          {isDiscountApplied && <p className="text-green-600 mt-2 text-sm">Desconto de 10% aplicado!</p>}
        </div>
      </main>
      
      <footer className="p-4 border-t border-slate-200">
        <button className="w-full bg-blue-600 text-white font-bold py-4 rounded-full text-lg shadow-lg shadow-blue-300/50 hover:bg-blue-700 transition-colors">
          Assinar Agora por {getPrice(selectedPlan)}
        </button>
      </footer>
    </div>
  );
};

interface PlanCardProps {
    plan: SubscriptionPlan;
    price: string;
    period: string;
    badge?: string;
    isSelected: boolean;
    onClick: () => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, price, period, badge, isSelected, onClick }) => (
    <div onClick={onClick} className={`relative p-4 border-2 rounded-2xl text-left cursor-pointer transition-all ${isSelected ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-white'}`}>
        {badge && <div className="absolute -top-3 right-4 bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full">{badge}</div>}
        <div className="flex items-center">
            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mr-4 ${isSelected ? 'border-blue-600' : 'border-slate-300'}`}>
                {isSelected && <div className="w-2.5 h-2.5 bg-blue-600 rounded-full"></div>}
            </div>
            <div>
                <span className="font-bold text-slate-800">{plan === 'monthly' ? 'Plano Mensal' : 'Plano Anual'}</span>
                <p className="text-slate-600"><span className="font-bold text-xl">{price}</span>{period}</p>
            </div>
        </div>
    </div>
);

export default PremiumScreen;