import React from 'react';
import type { SavedAudio } from '../types';
import { ChevronLeft, Play, Trash2, Music } from 'lucide-react';

interface LibraryScreenProps {
  savedAudios: SavedAudio[];
  onDelete: (id: string) => void;
  onPlay: (audio: SavedAudio) => void;
  onBack: () => void;
}

const LibraryScreen: React.FC<LibraryScreenProps> = ({ savedAudios, onDelete, onPlay, onBack }) => {

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm("Tem certeza que deseja apagar este áudio?")) {
      onDelete(id);
    }
  };
  
  return (
    <div className="flex flex-col h-full bg-slate-50">
      <header className="sticky top-0 bg-slate-50/80 backdrop-blur-sm p-4 flex items-center border-b border-slate-200/80 z-10">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-black/5"><ChevronLeft className="w-6 h-6 text-slate-600"/></button>
        <h2 className="text-xl font-bold text-slate-800 ml-4">Meus Áudios</h2>
      </header>

      <main className="flex-grow p-4 overflow-y-auto">
        {savedAudios.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-slate-500">
            <Music className="w-16 h-16 mb-4 text-slate-300" />
            <h3 className="text-lg font-semibold">Sua biblioteca está vazia</h3>
            <p className="max-w-xs mt-1">Os áudios que você salvar aparecerão aqui.</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {savedAudios.sort((a,b) => b.timestamp - a.timestamp).map(audio => (
              <li 
                key={audio.id}
                onClick={() => onPlay(audio)}
                className="flex items-center p-3 bg-white rounded-2xl shadow-sm shadow-slate-200/50 border border-slate-100 cursor-pointer hover:bg-blue-50 transition-colors"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
                   <Play className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-grow">
                  <p className="font-semibold text-slate-800 truncate">{audio.title}</p>
                  <p className="text-sm text-slate-500 truncate">{audio.text}</p>
                </div>
                <button 
                  onClick={(e) => handleDelete(e, audio.id)}
                  className="p-2 rounded-full hover:bg-red-100 text-slate-500 hover:text-red-600 ml-2"
                  aria-label="Apagar áudio"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
};

export default LibraryScreen;