import React, { useState } from 'react';
import { Play, Pause, RotateCcw, SkipBack, SkipForward, ChevronLeft, Save, LoaderCircle } from 'lucide-react';
import { useAudioPlayer } from '../hooks/useAudioPlayer';

interface PlayerScreenProps {
  text: string;
  audioB64: string;
  onSave: (title: string, text: string, audioB64: string) => void;
  onBack: () => void;
}

const PlayerScreen: React.FC<PlayerScreenProps> = ({ text, audioB64, onSave, onBack }) => {
  const { isPlaying, progress, duration, isReady, togglePlayPause, seek, skip } = useAudioPlayer(audioB64);
  const [title, setTitle] = useState(text.substring(0, 30) + '...');

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds === Infinity) return '00:00';
    const floorSeconds = Math.floor(seconds);
    const min = Math.floor(floorSeconds / 60);
    const sec = floorSeconds % 60;
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const handleSave = () => {
    const newTitle = prompt("Dê um nome para este áudio:", title);
    if (newTitle) {
      setTitle(newTitle);
      onSave(newTitle, text, audioB64);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-slate-50 to-white p-6">
      <header className="flex items-center justify-between">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-black/5"><ChevronLeft className="w-6 h-6 text-slate-600"/></button>
        <h2 className="text-lg font-semibold text-slate-700">Ouvindo Agora</h2>
        <button onClick={handleSave} className="p-2 rounded-full hover:bg-black/5"><Save className="w-6 h-6 text-slate-600"/></button>
      </header>

      <main className="flex-grow flex flex-col justify-center items-center text-center px-4">
        <div className="w-48 h-48 bg-white rounded-3xl shadow-xl shadow-slate-200/80 flex items-center justify-center mb-8">
            <img src={`https://picsum.photos/seed/${text.substring(0,5)}/200`} alt="Album Art" className="w-full h-full object-cover rounded-3xl"/>
        </div>
        <h3 className="text-xl font-bold text-slate-800">{title}</h3>
        <p className="text-slate-500 mt-1 text-sm">{text.substring(0, 70)}...</p>
      </main>

      <footer className="space-y-4">
        {/* Progress Bar */}
        <div className="space-y-2">
          <input
            type="range"
            min="0"
            max="1"
            step="0.001"
            value={progress}
            onChange={(e) => seek(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-200 rounded-full appearance-none cursor-pointer range-lg [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:rounded-full"
          />
          <div className="flex justify-between text-xs font-medium text-slate-500">
            <span>{formatTime(progress * duration)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
        
        {/* Controls */}
        <div className="flex items-center justify-center space-x-6">
          <button onClick={() => skip(-10)} className="text-slate-600 p-2 rounded-full hover:bg-slate-100"><SkipBack className="w-7 h-7" /></button>
          
          <button 
            onClick={togglePlayPause} 
            disabled={!isReady}
            className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-300/70 disabled:bg-slate-300 disabled:shadow-none"
          >
            {!isReady ? <LoaderCircle className="w-8 h-8 animate-spin" /> : isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
          </button>
          
          <button onClick={() => skip(10)} className="text-slate-600 p-2 rounded-full hover:bg-slate-100"><SkipForward className="w-7 h-7" /></button>
        </div>
      </footer>
    </div>
  );
};

export default PlayerScreen;