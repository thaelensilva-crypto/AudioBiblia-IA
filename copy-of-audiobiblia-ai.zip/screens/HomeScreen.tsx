import React from 'react';
import type { Screen } from '../types';
import { Camera, Music, Gem, BookAudio } from 'lucide-react';

interface HomeScreenProps {
  setCurrentScreen: (screen: Screen) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ setCurrentScreen }) => {
  return (
    <div className="flex flex-col h-full bg-white p-6 text-center justify-between">
      <div/>
      <main className="flex-grow flex flex-col justify-center items-center">
        <div className="mb-6 inline-flex items-center bg-slate-100 rounded-full px-4 py-1 text-sm text-slate-600 font-medium">
          <BookAudio className="w-4 h-4 mr-2 text-slate-500" />
          A Palavra que você ouve.
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 leading-tight">
          Transforme a Bíblia em <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-sky-500">
            Áudio Natural
          </span>
        </h1>
        <p className="mt-4 max-w-md mx-auto text-slate-500">
          Escaneie versículos com a câmera e ouça com uma voz suave e perfeita para longas leituras.
        </p>
        <div className="mt-8 space-y-3 w-full max-w-xs">
          <button
            onClick={() => setCurrentScreen('camera')}
            className="w-full flex items-center justify-center bg-blue-600 text-white font-semibold py-3 px-6 rounded-xl text-lg shadow-lg shadow-blue-300/50 hover:bg-blue-700 transition-all duration-300 transform hover:scale-105"
          >
            <Camera className="mr-3 h-5 w-5" />
            Começar Agora
          </button>
          <button
            onClick={() => setCurrentScreen('library')}
            className="w-full flex items-center justify-center bg-white text-slate-700 border border-slate-200 font-semibold py-3 px-6 rounded-xl text-lg shadow-sm shadow-slate-200/50 hover:bg-slate-50 transition-all duration-300"
          >
            <Music className="mr-3 h-5 w-5" />
            Meus Áudios
          </button>
        </div>
        <p className="mt-4 text-xs text-slate-400">
          3 scans grátis por dia • Sem cartão de crédito
        </p>
      </main>

      <footer className="py-2">
        <button
          onClick={() => setCurrentScreen('premium')}
          className="w-full flex items-center justify-center bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-800 font-bold py-3 px-6 rounded-xl text-md shadow-md shadow-amber-200/50 hover:opacity-90 transition-opacity duration-300"
        >
          <Gem className="mr-2 h-5 w-5" />
          Upgrade para Premium
        </button>
      </footer>
    </div>
  );
};

export default HomeScreen;