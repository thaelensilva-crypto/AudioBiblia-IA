import React, { useState, useEffect } from 'react';
import type { Screen, SavedAudio } from './types';
import HomeScreen from './screens/HomeScreen';
import CameraScreen from './screens/CameraScreen';
import ReviewScreen from './screens/ReviewScreen';
import PlayerScreen from './screens/PlayerScreen';
import LibraryScreen from './screens/LibraryScreen';
import PremiumScreen from './screens/PremiumScreen';
import { generateSpeech } from './services/geminiService';
import { MOCK_BIBLE_TEXT } from './constants';
import { LoaderCircle, AlertCircle } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [scannedText, setScannedText] = useState<string>('');
  const [generatedAudio, setGeneratedAudio] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [savedAudios, setSavedAudios] = useState<SavedAudio[]>([]);
  const [audioToPlay, setAudioToPlay] = useState<SavedAudio | null>(null);

  useEffect(() => {
    try {
      const storedAudios = localStorage.getItem('audiobiblia_saved');
      if (storedAudios) {
        setSavedAudios(JSON.parse(storedAudios));
      }
    } catch (e) {
      console.error("Failed to load saved audios from localStorage", e);
    }
  }, []);

  const handleSaveAudio = (title: string, text: string, audioB64: string) => {
    const newAudio: SavedAudio = {
      id: Date.now().toString(),
      title,
      text,
      audioB64,
      timestamp: Date.now(),
    };
    const updatedAudios = [...savedAudios, newAudio];
    setSavedAudios(updatedAudios);
    try {
      localStorage.setItem('audiobiblia_saved', JSON.stringify(updatedAudios));
    } catch (e) {
      console.error("Failed to save audio to localStorage", e);
    }
    setCurrentScreen('library');
  };

  const handleDeleteAudio = (id: string) => {
    const updatedAudios = savedAudios.filter(audio => audio.id !== id);
    setSavedAudios(updatedAudios);
     try {
      localStorage.setItem('audiobiblia_saved', JSON.stringify(updatedAudios));
    } catch (e) {
      console.error("Failed to update localStorage after deletion", e);
    }
  };

  const handlePlayFromLibrary = (audio: SavedAudio) => {
    setAudioToPlay(audio);
    setCurrentScreen('player');
  };

  const handleScanComplete = () => {
    setScannedText(MOCK_BIBLE_TEXT);
    setCurrentScreen('review');
  };

  const handleGenerateAudio = async (text: string) => {
    setIsLoading(true);
    setError(null);
    setScannedText(text);
    try {
      const audioB64 = await generateSpeech(text);
      setGeneratedAudio(audioB64);
      setAudioToPlay(null); // Clear library selection
      setCurrentScreen('player');
    } catch (err) {
      console.error(err);
      setError('Falha ao gerar o áudio. Por favor, tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen setCurrentScreen={setCurrentScreen} />;
      case 'camera':
        return <CameraScreen onScanComplete={handleScanComplete} />;
      case 'review':
        return <ReviewScreen text={scannedText} onGenerate={handleGenerateAudio} />;
      case 'player':
        if (audioToPlay) {
          return <PlayerScreen text={audioToPlay.text} audioB64={audioToPlay.audioB64} onSave={handleSaveAudio} onBack={() => setCurrentScreen('library')} />;
        }
        if (generatedAudio) {
          return <PlayerScreen text={scannedText} audioB64={generatedAudio} onSave={handleSaveAudio} onBack={() => setCurrentScreen('review')} />;
        }
        return <HomeScreen setCurrentScreen={setCurrentScreen} />; // Fallback
      case 'library':
        return <LibraryScreen savedAudios={savedAudios} onDelete={handleDeleteAudio} onPlay={handlePlayFromLibrary} onBack={() => setCurrentScreen('home')} />;
      case 'premium':
        return <PremiumScreen onBack={() => setCurrentScreen('home')} />;
      default:
        return <HomeScreen setCurrentScreen={setCurrentScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-sm h-[85vh] max-h-[800px] bg-white rounded-3xl shadow-2xl shadow-slate-300/50 flex flex-col overflow-hidden relative">
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-50">
            <LoaderCircle className="w-12 h-12 text-blue-600 animate-spin" />
            <p className="mt-4 text-slate-600">Gerando seu áudio...</p>
          </div>
        )}
        {error && !isLoading && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-50 p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-500" />
            <p className="mt-4 text-red-600">{error}</p>
            <button 
              onClick={() => { setError(null); setCurrentScreen('review'); }}
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-full"
            >
              Tentar Novamente
            </button>
          </div>
        )}
        <div className="flex-grow overflow-y-auto">
          {renderScreen()}
        </div>
      </div>
    </div>
  );
}