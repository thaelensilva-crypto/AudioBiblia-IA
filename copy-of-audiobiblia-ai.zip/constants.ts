
export const APP_NAME = "AudioBiblia AI";

export const MOCK_BIBLE_TEXT = "No princípio, criou Deus os céus e a terra. E a terra era sem forma e vazia; e havia trevas sobre a face do abismo; e o Espírito de Deus se movia sobre a face das águas. E disse Deus: Haja luz. E houve luz. E viu Deus que era boa a luz; e fez Deus separação entre a luz e as trevas.";
