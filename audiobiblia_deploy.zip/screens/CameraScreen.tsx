import React from 'react';
import { Camera, Zap } from 'lucide-react';

interface CameraScreenProps {
  onScanComplete: () => void;
}

const CameraScreen: React.FC<CameraScreenProps> = ({ onScanComplete }) => {
  return (
    <div className="flex flex-col h-full bg-black text-white">
      <div className="flex-grow relative flex items-center justify-center">
        {/* Placeholder for camera feed */}
        <div className="absolute inset-0 bg-slate-800 flex items-center justify-center">
          <p className="text-slate-400">Visualização da câmera simulada</p>
        </div>
        
        {/* OCR Guide Overlay */}
        <div className="absolute inset-0 p-8 flex items-center justify-center">
          <div className="w-full h-full border-4 border-dashed border-white/50 rounded-2xl flex flex-col items-center justify-center p-4">
            <p className="text-white/80 font-semibold">Posicione o texto aqui</p>
          </div>
        </div>
        
        {/* Top controls */}
        <div className="absolute top-0 left-0 right-0 p-4 flex justify-end">
          <button className="p-2 bg-black/30 rounded-full">
            <Zap className="h-6 w-6" />
          </button>
        </div>
      </div>
      
      <div className="bg-black/80 backdrop-blur-sm p-6 flex items-center justify-center">
        <button 
          onClick={onScanComplete}
          className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-2xl shadow-white/20 transform hover:scale-105 transition-transform"
          aria-label="Capturar Texto"
        >
          <div className="w-18 h-18 p-1 bg-white rounded-full">
            <div className="w-full h-full bg-blue-600 rounded-full flex items-center justify-center">
              <Camera className="h-8 w-8 text-white" />
            </div>
          </div>
        </button>
      </div>
    </div>
  );
};

export default CameraScreen;