import React, { useState } from 'react';
import { Wand2 } from 'lucide-react';

interface ReviewScreenProps {
  text: string;
  onGenerate: (text: string) => void;
}

const ReviewScreen: React.FC<ReviewScreenProps> = ({ text, onGenerate }) => {
  const [editedText, setEditedText] = useState(text);

  return (
    <div className="flex flex-col h-full p-6 bg-slate-50">
      <header>
        <h2 className="text-2xl font-bold text-slate-800">Revise o Texto</h2>
        <p className="text-slate-500 mt-1">Ajuste o texto escaneado antes de gerar o áudio.</p>
      </header>
      
      <div className="flex-grow my-4">
        <textarea
          value={editedText}
          onChange={(e) => setEditedText(e.target.value)}
          className="w-full h-full p-4 bg-white border border-slate-200 rounded-2xl resize-none focus:ring-2 focus:ring-blue-500 focus:outline-none text-slate-700 leading-relaxed"
        />
      </div>
      
      <footer className="py-2">
        <button
          onClick={() => onGenerate(editedText)}
          disabled={!editedText.trim()}
          className="w-full flex items-center justify-center bg-blue-600 text-white font-semibold py-4 px-6 rounded-full text-lg shadow-lg shadow-blue-300/50 hover:bg-blue-700 transition-all duration-300 disabled:bg-slate-300 disabled:shadow-none"
        >
          <Wand2 className="mr-3 h-6 w-6" />
          Gerar Áudio
        </button>
      </footer>
    </div>
  );
};

export default ReviewScreen;