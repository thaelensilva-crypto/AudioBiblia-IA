
export type Screen = 'home' | 'camera' | 'review' | 'player' | 'library' | 'premium';

export interface SavedAudio {
  id: string;
  title: string;
  text: string;
  audioB64: string;
  timestamp: number;
}

export type SubscriptionPlan = 'monthly' | 'annual';
