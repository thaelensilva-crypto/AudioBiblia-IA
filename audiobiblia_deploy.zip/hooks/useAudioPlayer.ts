
import { useState, useEffect, useRef, useCallback } from 'react';
import { decode, decodeAudioData } from '../utils/audio';

// Gemini TTS returns 24000Hz mono audio
const SAMPLE_RATE = 24000;
const NUM_CHANNELS = 1;

export const useAudioPlayer = (audioB64: string | null) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isReady, setIsReady] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const startTimeRef = useRef(0);
  const startedAtRef = useRef(0);
  const progressIntervalRef = useRef<number | null>(null);

  const cleanup = useCallback(() => {
    if (progressIntervalRef.current) {
      clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
    if (sourceNodeRef.current) {
      sourceNodeRef.current.stop();
      sourceNodeRef.current.disconnect();
      sourceNodeRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (audioB64) {
      setIsReady(false);
      const initAudio = async () => {
        try {
          if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: SAMPLE_RATE });
          }
          const audioBytes = decode(audioB64);
          const buffer = await decodeAudioData(audioBytes, audioContextRef.current, SAMPLE_RATE, NUM_CHANNELS);
          audioBufferRef.current = buffer;
          setDuration(buffer.duration);
          setIsReady(true);
          setProgress(0);
          setIsPlaying(false);
        } catch (error) {
          console.error("Failed to decode audio data", error);
        }
      };
      initAudio();
    }
    return cleanup;
  }, [audioB64, cleanup]);

  const play = useCallback(() => {
    if (!isReady || !audioBufferRef.current || !audioContextRef.current) return;

    if (audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
    }
    
    cleanup();
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBufferRef.current;
    source.connect(audioContextRef.current.destination);
    
    const offset = progress * duration;
    source.start(0, offset);
    
    sourceNodeRef.current = source;
    startedAtRef.current = audioContextRef.current.currentTime - offset;
    startTimeRef.current = Date.now() - (offset * 1000);

    setIsPlaying(true);

    progressIntervalRef.current = window.setInterval(() => {
      if (audioContextRef.current && audioBufferRef.current) {
        const elapsed = audioContextRef.current.currentTime - startedAtRef.current;
        const newProgress = Math.min(elapsed / duration, 1);
        setProgress(newProgress);
        if (newProgress >= 1) {
          pause();
          setProgress(1); // Ensure it ends at 100%
        }
      }
    }, 100);

     source.onended = () => {
        if (progress < 0.99) return;
        setIsPlaying(false);
        setProgress(0);
        if (progressIntervalRef.current) {
          clearInterval(progressIntervalRef.current);
        }
    };

  }, [isReady, duration, progress, cleanup]);

  const pause = useCallback(() => {
    cleanup();
    setIsPlaying(false);
  }, [cleanup]);

  const seek = (newProgress: number) => {
    if (!duration) return;
    const wasPlaying = isPlaying;
    pause();
    setProgress(newProgress);
    if (wasPlaying) {
      play();
    }
  };

  const skip = (amount: number) => {
    const newTime = progress * duration + amount;
    const newProgress = Math.max(0, Math.min(newTime / duration, 1));
    seek(newProgress);
  }

  const togglePlayPause = () => {
    if (isPlaying) {
      pause();
    } else {
      if (progress >= 1) { // If at the end, restart
          setProgress(0);
          const wasPlaying = isPlaying;
          if (!wasPlaying) {
             setTimeout(play, 0);
          }
      } else {
          play();
      }
    }
  };

  return { isPlaying, progress, duration, isReady, togglePlayPause, seek, skip };
};
